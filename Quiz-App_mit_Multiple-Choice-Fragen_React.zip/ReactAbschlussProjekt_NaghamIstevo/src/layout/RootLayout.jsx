/**
 * Root Layout für alle Seiten.
 * Hier können Header, Footer, Navigation etc. platziert werden.
 * <Outlet /> rendert die jeweils passende Unterseite.
 */
import MainNavigation from "../components/MainNavigation.jsx";
import {Outlet} from "react-router-dom";

function RootLayout() {
    return (
        <>
        <MainNavigation/>
            <main>
                {/* This is where the child routes will be rendered */}
                <Outlet />
            </main>
        </>
    )
}

export default RootLayout;
