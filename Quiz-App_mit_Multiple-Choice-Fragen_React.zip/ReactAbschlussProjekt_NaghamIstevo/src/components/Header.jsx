/**
 * @component
 *Seite zur Anzeige Header zeigen
 */
import mathLogo from '../assets/mathLogo.png';

export default function Header({...props}){
    return(
        <header className='mathLogo'>
          <img src={mathLogo} {...props} />
        </header>
    );
    
}