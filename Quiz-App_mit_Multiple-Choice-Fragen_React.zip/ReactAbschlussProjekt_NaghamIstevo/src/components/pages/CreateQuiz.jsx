/**
 * Seite zum Erstellen eigener Quizze.
 * Erlaubt das Hinzufügen von Fragen und Speichern im localStorage.
 *
 * @component
 * @returns {JSX.Element}
 */

import classes from './CreateQuiz.module.css';
import { useState} from 'react';
import { useNavigate } from 'react-router-dom';
import { saveNewQuiz } from '../../store/quizSlice';
import { useDispatch } from 'react-redux';

export default function CreateQuiz() {
    const [name, setName] = useState('');
    const [questions, setQuestions] = useState([]);
    const dispatch=useDispatch();
    const navigate = useNavigate();

    function addQuestion(){
        setQuestions([...questions,{id:'',question:'',answers:['','',''],correctAnswer:0}]);
    };
    function handleSave(){
        if (!name || questions.length === 0) return alert("Bitte Quizname & Fragen eingeben");
        dispatch(saveNewQuiz({ name, questions }));
        navigate('/');
    }
    return(
        <div className={classes.hauptContainer}>
            <div className={classes.text}>
                <h2>Eigenes Quiz erstellen</h2>
            </div>
            <div >
                <input placeholder="quizname" value={name} onChange={e=> setName(e.target.value)}/>
                <button onClick={addQuestion}>Schreiben Sie Ihre gewünschte Frage in {name}</button>

                {questions.map((q,id)=>(
                    <div key={id}>
                        <input placeholder='Frage hinfügen' value={q.question} onChange={e=>{
                            const updated=[...questions];
                            updated[id].id={id};
                            updated[id].question=e.target.value;
                            setQuestions(updated);
                        }}
                        />
                        {q.answers.map((ans,idx)=>(
                            <input key={idx} placeholder={`answers ${idx+1}`}  value={ans} onChange={e=>{
                                const updated =[...questions];
                                updated[id].answers[idx]=e.target.value;
                                setQuestions(updated);
                            }}
                            />
                        
                        ))}

                    </div>

                ))}
                <button onClick={handleSave}>Quiz speichern</button>
            </div>
        </div>
    );














}