/**
 * @component
 * Start Seite, hier wird die Navigation  
 * zur Anzeige des Button "Quiz starten" und "Eigenes Quiz erstellen"
 * 
 */

import classes from './HomePage.module.css';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { resetScore} from'../../store/quizSlice.js';

export default function HomePage() {
  const dispatch = useDispatch();
  const navigate=useNavigate();

  function handleStartQuiz(){
    dispatch(resetScore());
    navigate('/QuizReduxComponent');
  }
  function handleQuizErstellen(){
    navigate('/CreateQuiz');
  }
  
  return (
      <div className={classes.hauptContainer}>
        <div className={classes.text}>
          <h1>Willkommen zum Quiz</h1>
        </div>
        <div className={classes.buttonContainer}>
           <div className={classes.btnstarten}>
             <button onClick={handleStartQuiz}>Quiz starten</button>
           </div>
           <div className={classes.btnQuizErstellen}>
             <button onClick={handleQuizErstellen}>Eigenes Quiz erstellen</button>
           </div>
        </div>
      </div>
  );
}
