/**
 * Seite zur Anzeige des Spielergebnisses nach Quizende.
 * Zeigt Punktzahl und gespeicherte Highscores.
 *
 * @component
 * @returns {JSX.Element}
 */

import classes from './ResultPage.module.css';
import { useSelector } from 'react-redux';
import { saveHighscore } from '../../utils/storage';
import { useNavigate } from 'react-router-dom';
import { resetQuiz} from'../../store/quizSlice.js';
import { useDispatch } from 'react-redux';

export default function ResultPage() {

  const {
    TEST01,
    score,
   
  } = useSelector((state) => state.quiz);
 

  const dispatch = useDispatch();
  const navigate = useNavigate();

  saveHighscore(score);
  const handleReset = () => {
    navigate('/QuizReduxComponent');
  };
  
  const handleRestart = () => {
    dispatch( resetQuiz()); 
    navigate('/');
  };
  return (
    <div className={classes.hauptContainerResultPage}>
      
        <h2>Quiz finished!</h2>
        <p>Score: {score}</p>       
        <button onClick={handleReset}>Restart</button>
        <p> Dein Ergebnis ist: {score}/ {TEST01.length}</p>
        <button onClick={handleRestart}>Zurück zur Startseite</button>
      </div>
  );
}
