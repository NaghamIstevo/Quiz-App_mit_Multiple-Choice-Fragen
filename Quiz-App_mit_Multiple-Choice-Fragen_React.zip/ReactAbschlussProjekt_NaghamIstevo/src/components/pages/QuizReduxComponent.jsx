/**
 * Seite zur Anzeige der aktuellen Quizfrage.
 * Zeigt Frage, Antwortmöglichkeiten und Timer.
 *
 * @component
 * @returns {JSX.Element}
 */

import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { loadQuestions, answerQuestion, nextQuestion, resetQuiz, setPlayerName,saveHighScore } from'../../store/quizSlice.js';
import Header from '../Header.jsx';
import TimerChallenge from '../TimerChallenge.jsx';
import ResultPage from './ResultPage.jsx';

const QuizReduxComponent = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [showTimeoutMessage, setShowTimeoutMessage] = useState(false);

  // Accessing state
  const {
    TEST01,
    currentIndex,
    isFinished,
    playerName,
  } = useSelector((state) => state.quiz);
 
  const currentQuestion = TEST01[currentIndex];
 
  const handleAnswer = (answer) => {
    dispatch(answerQuestion(answer));   
  };
  const handleNext = () => {
    dispatch(nextQuestion());
    setShowTimeoutMessage(false);
  };

  const handleTimeout = () => {
    setShowTimeoutMessage(true);
  };

  if (isFinished){
    return(
      <>
       <ResultPage/>
      </>
    );
  }

  return (

    <>
        <div className="haupt-container">
            <Header className="mathLogo" alt="Math Logo"/>
            <h2>Hello, {playerName || 'Guest'}!</h2>
            {currentQuestion && (
            <div className='main-cotainer'>
                <div>
                  <TimerChallenge
                   duration={5} 
                   onTimeout={handleTimeout} 
                   questionIndex={currentIndex}/> {/* questionIndex erzwingt Neumount bei jeder Frage sonst wird Time nicht zurücksetzen */}
                  {showTimeoutMessage && <p>❗ Zeit abgelaufen! Bitte drücken Sie auf next!</p>}
                  </div>
                <div className='frage-antwort-container'>
                    <div className='aktuelFrage'><p>Frage {currentIndex+1}/{TEST01.length}</p> </div>
                    <div className='frage-box'>
                        <div className='frage-text'><p><b>{currentQuestion.question}</b></p></div>
                    </div>
                    <div className='frage-line'></div>
                    <div className='antwort-container'>
                        <div className='checkbox-antwort'>
                            <ul>
                                {currentQuestion.answers.map((answer,index)=>(
                                    <li key={index}>
                                       
                                         <button
                                            onClick={() => handleAnswer(answer)}                               
                                        >
                                        {answer}
                                        </button>
                                   </li>
                                ))}
                            </ul>
                                            
                        </div>
                                    
                    </div>
                </div>
                <div>
                <div className='footer' ><button className='next-button' onClick={handleNext}>Next</button></div>
                </div>
          </div>
          
          )}
        </div> 
        
        </>

  
  );
};

export default QuizReduxComponent;


