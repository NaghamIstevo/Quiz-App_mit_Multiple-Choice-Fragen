/**
 * @component
 * Seite zur Anzeige der Navigations zwischen HomePage,Quiz, Create Quiz und Result Page .
 */
import classes from './MainNavigation.module.css';
import {Link} from "react-router-dom";

function MainNavigation() {
    return (
        <header className={classes.header}>
            <nav>
                <ul className={classes.list}>
                    <li>
                        <Link to="/">HomePage</Link>
                    </li>
                    <li>
                        <Link to="/QuizReduxComponent">Quiz</Link>
                    </li>
                    <li>
                        <Link to="/CreateQuiz">Create Quiz</Link>
                    </li>
                    <li>
                        <Link to="/ResultPage">Result Page</Link>
                    </li>
                    
                </ul>
            </nav>
        </header>
    )
}

export default MainNavigation;
