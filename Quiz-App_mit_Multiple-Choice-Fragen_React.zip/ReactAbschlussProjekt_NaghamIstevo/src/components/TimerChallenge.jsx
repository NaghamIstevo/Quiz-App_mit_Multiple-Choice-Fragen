/**
 * Timer-Komponente, die für jede Frage herunterzählt.
 * Ruft Callback auf, wenn die Zeit abläuft.
 *
 * @component
 * @param {Object} props
 * @param {number} props.duration - Dauer des Timers in Sekunden.
 * @param {Function} props.onTimeout - Callback bei Ablauf.
 * @returns {JSX.Element}
 */

import React, { useEffect, useState } from 'react';

const TimerChallenge = ({ duration, onTimeout, questionIndex  }) => {
  const [timeLeft, setTimeLeft] = useState(duration);

  useEffect(() => {
    setTimeLeft(duration); // Reset bei jeder neuen Frage
  }, [duration, questionIndex ]);// <-- Achtung: auch auf questionIndex reagieren!

  useEffect(() => {
    if (timeLeft === 0) {
      onTimeout();
      return;
    }

    const timer = setTimeout(() => setTimeLeft(t => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft]);

  return <div>⏱ Zeit: {timeLeft}s</div>;
};

export default TimerChallenge;
