/**
 * @component
 * Eine Fehlerseite wird definiert, um benutzerfreundliche Fehlermeldungen anzuzeigen.
 */
import MainNavigation from "../MainNavigation.jsx";

function ErrorPage() {
    return (
        <>
            <MainNavigation/>
            <main>
                <h1 style={{color:blue}}>An error occurred!</h1>
                <p style={{color:blue}}>Could not find this page!</p>
            </main>
        </>
    );
}

export default ErrorPage;
