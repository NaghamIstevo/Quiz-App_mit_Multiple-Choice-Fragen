/**
 * Hauptkomponente der Anwendung.
 * Verwaltet die Routen mit React Router.
 *
 * @component
 * @returns {JSX.Element} Die Router-gebundene Anwendung.
 */

import {createBrowserRouter, RouterProvider} from "react-router-dom";
import QuizReduxComponent from "./components/pages/QuizReduxComponent.jsx";
import HomePage from "./components/pages/HomePage.jsx";
import ResultPage from "./components/pages/ResultPage.jsx";
import CreateQuiz from "./components/pages/CreateQuiz.jsx";
import RootLayout from "./layout/RootLayout.jsx";
import Error from "./components/error/Error.jsx";

const router = createBrowserRouter([
  {
      path: '/',
      element: <RootLayout/>,
      errorElement: <Error/>,
      children: [
          {path: '/', element: <HomePage/> },
          {path: '/QuizReduxComponent', element: <QuizReduxComponent/> },
          {path: '/CreateQuiz', element: <CreateQuiz/> },
          {path: '/ResultPage', element: <ResultPage/> },
          
      ]
  }
])

function App() {
 

  return (
    <>
     <RouterProvider router={router} />
    {/* <Routes>
     
    </Routes> */}
   {/*  <Quiz /> */}
   
{/* <QuizReduxComponent/> */}
       
    </>
  )
}

export default App
