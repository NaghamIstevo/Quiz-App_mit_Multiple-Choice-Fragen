/**
 * @typedef {Object} Question
 * @property {string} TEST01 - Die gestellte Frage.
 * @property {string[]} answers - Array der Antwortmöglichkeiten.
 */

/**
 * @typedef {Object} HighscoreEntry
 * @property {string} playerName - Name des Spielers.
 * @property {number} score - Punktzahl.
 */



import TEST01 from '../data/MatheQuestion.json'

import { createSlice } from '@reduxjs/toolkit';

import { saveHighscore } from '../utils/storage';



const initialState = {
  TEST01,
  currentIndex: 0,
  answers: [],
  isFinished: false,
  score: 0,
  highscore: JSON.parse(localStorage.getItem('highscore')) ||{ score: 0, playerName: '' },
  highscores: JSON.parse(localStorage.getItem('highscores')) || [],
  playerName: '',
  quizzes: [],
};


const quizSlice = createSlice({
  name: 'quiz',
  initialState,
  reducers: {
    loadQuestions: (state, action) => {
      state.TEST01 = action.payload;
    },
    answerQuestion(state, action) {
      const current = state.TEST01[state.currentIndex];
      if (action.payload === current.answers[0]) {
        state.score += 1;
        if( state.score >state.TEST01.length){
          state.score=state.TEST01.length;
        }
      }
   
    },
    resetQuiz: (state) => {
      state.currentIndex = 0;
      state.answers = [];
      state.score = 0;
     
      state.isFinished = false;
    },
    nextQuestion: (state) => {
      if (state.currentIndex < state.TEST01.length - 1) {
        state.currentIndex += 1;
       
      } else {
        state.isFinished = true;
        if (state.score > state.highscore.score) {
          state.highscore = {
            score: state.score,
            playerName: state.playerName,
          };
          saveHighscore(state.highscore);
        }
      }
    },
    setPlayerName: (state, action) => {
      state.playerName = action.payload;
    },
    saveHighScore(state) {
      const entry = {
        name: state.playerName,
        score: state.score,
      };
      state.highscores.push(entry);
      localStorage.setItem('highscores', JSON.stringify(state.highscores));

    },
    saveNewQuiz(state, action) {
      state.quizzes.push(action.payload);
      localStorage.setItem('custom_quizzes', JSON.stringify(state.quizzes));
    },
    loadUserQuizzes(state) {
      const saved = JSON.parse(localStorage.getItem('custom_quizzes')) || [];
      state.quizzes = saved;
    },
    resetScore(state) {
      state.score = 0;
    },
  },
});

export const { loadQuestions, answerQuestion, resetQuiz, setPlayerName,nextQuestion,saveHighScore,saveNewQuiz,loadUserQuizzes,resetScore } = quizSlice.actions;
export default quizSlice.reducer;

