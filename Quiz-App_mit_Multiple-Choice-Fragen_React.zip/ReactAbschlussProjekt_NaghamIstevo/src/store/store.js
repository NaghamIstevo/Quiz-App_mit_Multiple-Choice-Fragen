/**
 * Konfiguriert den Redux Store für die Quizanwendung.
 * Verwendet Redux Toolkit.
 *
 * @returns {Store}
 */

import { configureStore } from '@reduxjs/toolkit';
import quizReducer from './quizSlice';

const store = configureStore({
  reducer: {
    quiz: quizReducer,
  },
});

export default store;
