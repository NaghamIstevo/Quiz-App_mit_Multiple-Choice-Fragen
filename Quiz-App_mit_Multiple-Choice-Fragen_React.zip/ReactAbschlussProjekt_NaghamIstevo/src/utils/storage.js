const QUIZ_KEY = 'custom_quizzes';
const HIGHSCORE_KEY = 'highscores';
/**
 *  Speichert den neuen gestellten Qiuz im localStorage.
 * @param {*} name 
 * @param {*} questions 
 */
export function saveUserQuiz(name, questions) {
  const all = JSON.parse(localStorage.getItem(QUIZ_KEY)) || {};
  all[name] = questions;
  localStorage.setItem(QUIZ_KEY, JSON.stringify(all));
}
/**
 * 
 * @returns name und question, das gespeicherte userQuiz
 */
export function getUserQuizzes() {
  return JSON.parse(localStorage.getItem(QUIZ_KEY)) || {};
}
/**
 * Speichert den aktuellen Highscore im localStorage.
 * @param {{score: number, playerName: string}} highscore - Das Highscore-Objekt.
 */
export function saveHighscore(player, score) {
  const scores = JSON.parse(localStorage.getItem(HIGHSCORE_KEY)) || {};
  scores[player] = Math.max(scores[player] || 0, score);
  localStorage.setItem(HIGHSCORE_KEY, JSON.stringify(scores));
}
/**
 * Lädt den gespeicherten Highscore aus dem localStorage.
 * @returns {{score: number, playerName: string} | null} Das gespeicherte Highscore-Objekt.
 */
export function loadHighscore() {
  return JSON.parse(localStorage.getItem(HIGHSCORE_KEY)) || {};
}
  